public class Booking {
    private String name;
    private String roomType;
    private int nights;

    // Exchange rate from USD to Pesos
    private static final double PESO_CONVERSION_RATE = 55.0; // 1 USD = 55 Pesos

    public Booking(String name, String roomType, int nights) {
        this.name = name;
        this.roomType = roomType;
        this.nights = nights;
    }

    public String getName() { return name; }
    public String getRoomType() { return roomType; }
    public int getNights() { return nights; }

    public void setRoomType(String roomType) { this.roomType = roomType; }
    public void setNights(int nights) { this.nights = nights; }

    public int getTotalCost() {
        int rateUSD;
        switch (roomType.toLowerCase()) {
            case "single":
                rateUSD = 100;
                break;
            case "double":
                rateUSD = 150;
                break;
            case "suite":
                rateUSD = 250;
                break;
            default:
                rateUSD = 0;
                break;
        }
        return (int)(rateUSD * nights * PESO_CONVERSION_RATE);
    }

    @Override
    public String toString() {
        return name + "," + roomType + "," + nights;
    }

    public static Booking fromString(String data) {
        try {
            String[] parts = data.split(",");
            if (parts.length != 3) {
                throw new IllegalArgumentException("Invalid booking data format");
            }
            String name = parts[0];
            String roomType = parts[1];
            int nights = Integer.parseInt(parts[2]);
            
            if (name.isEmpty()) {
                throw new IllegalArgumentException("Name cannot be empty");
            }
            
            if (nights <= 0) {
                throw new IllegalArgumentException("Nights must be greater than zero");
            }
            
            return new Booking(name, roomType, nights);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number format for nights: " + e.getMessage());
        }
    }
}
