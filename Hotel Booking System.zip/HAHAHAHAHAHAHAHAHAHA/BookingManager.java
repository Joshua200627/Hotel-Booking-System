import java.io.*;
import java.util.*;

public class BookingManager {
    private final String filePath = "bookings.txt";
    // Define total number of rooms by type
    public final int TOTAL_SINGLE_ROOMS = 10;
    public final int TOTAL_DOUBLE_ROOMS = 8;
    public final int TOTAL_SUITE_ROOMS = 5;

    public void addBooking(Booking booking) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(booking.toString());
            writer.newLine();
        }
    }

    public List<Booking> getAllBookings() throws IOException {
        List<Booking> bookings = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) return bookings;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                try {
                    bookings.add(Booking.fromString(line));
                } catch (IllegalArgumentException e) {
                    System.err.println("Warning: Skipping invalid booking at line " + lineNumber + ": " + e.getMessage());
                }
            }
        }
        return bookings;
    }

    public void updateBooking(String name, Booking updatedBooking) throws IOException {
        List<Booking> bookings = getAllBookings();
        boolean found = false;
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Booking b : bookings) {
                if (b.getName().equalsIgnoreCase(name)) {
                    writer.write(updatedBooking.toString());
                    found = true;
                } else {
                    writer.write(b.toString());
                }
                writer.newLine();
            }
        }
        
        if (!found) {
            throw new IOException("Booking with name '" + name + "' not found");
        }
    }

    public void deleteBooking(String name) throws IOException {
        List<Booking> bookings = getAllBookings();
        boolean found = false;
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Booking b : bookings) {
                if (!b.getName().equalsIgnoreCase(name)) {
                    writer.write(b.toString());
                    writer.newLine();
                } else {
                    found = true;
                }
            }
        }
        
        if (!found) {
            throw new IOException("Booking with name '" + name + "' not found");
        }
    }

    public int getAvailableRooms(String roomType) throws IOException {
        List<Booking> bookings = getAllBookings();
        int booked = 0;
        
        for (Booking b : bookings) {
            if (b.getRoomType().equalsIgnoreCase(roomType)) {
                booked++;
            }
        }
        
        switch (roomType.toLowerCase()) {
            case "single":
                return TOTAL_SINGLE_ROOMS - booked;
            case "double":
                return TOTAL_DOUBLE_ROOMS - booked;
            case "suite":
                return TOTAL_SUITE_ROOMS - booked;
            default:
                return 0;
        }
    }
    
    public String getAvailabilityInfo() throws IOException {
        int singleAvailable = getAvailableRooms("single");
        int doubleAvailable = getAvailableRooms("double");
        int suiteAvailable = getAvailableRooms("suite");
        
        return String.format("Available Rooms:\n- Single: %d/%d\n- Double: %d/%d\n- Suite: %d/%d",
            singleAvailable, TOTAL_SINGLE_ROOMS,
            doubleAvailable, TOTAL_DOUBLE_ROOMS,
            suiteAvailable, TOTAL_SUITE_ROOMS);
    }
}
