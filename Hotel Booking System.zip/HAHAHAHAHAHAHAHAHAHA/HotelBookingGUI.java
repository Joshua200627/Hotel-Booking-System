import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HotelBookingGUI extends JFrame {
    private JTextField nameField, nightsField;
    private JComboBox<String> roomTypeBox;
    private JEditorPane outputArea;
    private BookingManager manager;
    private JPanel mainPanel, welcomePanel, bookingPanel;
    private CardLayout cardLayout = new CardLayout();
    
    // Define colors for the UI
    private final Color PRIMARY_COLOR = new Color(70, 130, 180); // Steel Blue
    private final Color SECONDARY_COLOR = new Color(240, 248, 255); // Alice Blue
    private final Color ACCENT_COLOR = new Color(25, 25, 112); // Midnight Blue
    private final Color SUCCESS_COLOR = new Color(46, 204, 113); // Emerald
    private final Color ERROR_COLOR = new Color(231, 76, 60); // Alizarin
    private final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 32);
    private final Font SUBTITLE_FONT = new Font("Segoe UI", Font.PLAIN, 18);
    private final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 16);
    private final int BORDER_RADIUS = 8;

    public HotelBookingGUI() {
        manager = new BookingManager();

        setTitle("Hotel Booking System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(SECONDARY_COLOR);
        
        // Create main panel with card layout
        mainPanel = new JPanel(cardLayout);
        add(mainPanel, BorderLayout.CENTER);
        
        // Create welcome screen
        createWelcomePanel();
        
        // Create booking management screen
        createBookingPanel();
        
        // Add panels to card layout
        mainPanel.add(welcomePanel, "welcome");
        mainPanel.add(bookingPanel, "booking");
        
        // Show welcome screen first
        cardLayout.show(mainPanel, "welcome");
        
        // Center the window on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void createWelcomePanel() {
        welcomePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create subtle background pattern
                g2d.setColor(new Color(230, 240, 250));
                int size = 20;
                for (int x = 0; x < getWidth(); x += size) {
                    for (int y = 0; y < getHeight(); y += size) {
                        g2d.fillOval(x, y, 2, 2);
                    }
                }
                g2d.dispose();
            }
        };
        welcomePanel.setBackground(SECONDARY_COLOR);
        welcomePanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        
        // Content panel for centered content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setOpaque(false);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Title
        JLabel titleLabel = new JLabel("Hotel Booking System");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Subtitle
        JLabel subtitleLabel = new JLabel("Book your perfect stay with ease");
        subtitleLabel.setFont(SUBTITLE_FONT);
        subtitleLabel.setForeground(ACCENT_COLOR);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Features list
        JPanel featuresPanel = new JPanel();
        featuresPanel.setLayout(new BoxLayout(featuresPanel, BoxLayout.Y_AXIS));
        featuresPanel.setOpaque(false);
        featuresPanel.setBorder(BorderFactory.createEmptyBorder(30, 0, 30, 0));
        
        String[] features = {
            "Book rooms quickly and easily",
            "Check room availability in real-time",
            "View all your bookings in one place",
            "Simple and elegant interface"
        };
        
        for (String feature : features) {
            JPanel featureRow = new JPanel(new FlowLayout(FlowLayout.CENTER));
            featureRow.setOpaque(false);
            
            JLabel featureLabel = new JLabel(feature);
            featureLabel.setFont(LABEL_FONT);
            featureLabel.setForeground(ACCENT_COLOR);
            
            featureRow.add(featureLabel);
            featuresPanel.add(featureRow);
            featuresPanel.add(Box.createVerticalStrut(10));
        }
        
        // Get Started button
        JButton getStartedButton = createStyledButton("Get Started", PRIMARY_COLOR);
        getStartedButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        getStartedButton.addActionListener(e -> cardLayout.show(mainPanel, "booking"));
        
        // Add components to content panel
        contentPanel.add(titleLabel);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(subtitleLabel);
        contentPanel.add(featuresPanel);
        contentPanel.add(getStartedButton);
        
        // Add content panel to welcome panel
        welcomePanel.add(contentPanel, BorderLayout.CENTER);
    }
    
    private void createBookingPanel() {
        bookingPanel = new JPanel(new BorderLayout());
        bookingPanel.setBackground(SECONDARY_COLOR);
        
        // Header panel with gradient
        JPanel titlePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth();
                int h = getHeight();
                GradientPaint gp = new GradientPaint(0, 0, ACCENT_COLOR, w, h, new Color(44, 62, 80));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
                g2d.dispose();
            }
        };
        titlePanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Hotel Booking System");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 0));
        titlePanel.add(titleLabel, BorderLayout.WEST);
        
        // Main content panel with padding
        JPanel contentPanel = new JPanel(new BorderLayout(15, 20));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        contentPanel.setBackground(SECONDARY_COLOR);
        
        // Form Panel with rounded corners
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(Color.WHITE);
                g2d.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), BORDER_RADIUS*2, BORDER_RADIUS*2));
                g2d.dispose();
            }
        };
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            new EmptyBorder(5, 5, 5, 5),
            new EmptyBorder(15, 15, 15, 15)
        ));
        formPanel.setOpaque(false);

        // Style the form components
        JLabel nameLabel = new JLabel("Guest Name:");
        nameLabel.setFont(LABEL_FONT);
        formPanel.add(nameLabel);
        
        nameField = createStyledTextField();
        formPanel.add(nameField);

        JLabel roomLabel = new JLabel("Room Type:");
        roomLabel.setFont(LABEL_FONT);
        formPanel.add(roomLabel);
        
        roomTypeBox = new JComboBox<>(new String[]{"Single", "Double", "Suite"});
        roomTypeBox.setFont(LABEL_FONT);
        roomTypeBox.setBackground(Color.WHITE);
        roomTypeBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        formPanel.add(roomTypeBox);

        JLabel nightsLabel = new JLabel("Number of Nights:");
        nightsLabel.setFont(LABEL_FONT);
        formPanel.add(nightsLabel);
        
        nightsField = createStyledTextField();
        formPanel.add(nightsField);

        // Create a panel for the form and buttons
        JPanel topPanel = new JPanel(new BorderLayout(0, 15));
        topPanel.setBackground(SECONDARY_COLOR);
        topPanel.add(formPanel, BorderLayout.NORTH);
        
        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        buttonPanel.setOpaque(false);
        
        JButton addBtn = createStyledButton("Add Booking", SUCCESS_COLOR);
        JButton viewBtn = createStyledButton("View All", PRIMARY_COLOR);
        JButton availabilityBtn = createStyledButton("Check Availability", new Color(142, 68, 173)); // Purple

        buttonPanel.add(addBtn);
        buttonPanel.add(viewBtn);
        buttonPanel.add(availabilityBtn);
        
        topPanel.add(buttonPanel, BorderLayout.CENTER);
        
        // Add the top panel to the content panel
        contentPanel.add(topPanel, BorderLayout.NORTH);

        // Output Area with rounded corners
        outputArea = new JEditorPane();
        outputArea.setEditable(false);
        outputArea.setContentType("text/html");
        outputArea.setMargin(new Insets(15, 15, 15, 15));
        outputArea.setFont(LABEL_FONT);
        outputArea.setBackground(Color.WHITE);
        outputArea.setBorder(BorderFactory.createEmptyBorder());
        
        // Add hyperlink listener for delete buttons
        outputArea.addHyperlinkListener(new HyperlinkListener() {
            @Override
            public void hyperlinkUpdate(HyperlinkEvent e) {
                if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                    String url = e.getDescription();
                    if (url.startsWith("delete://")) {
                        String name = url.substring(9);
                        int option = JOptionPane.showConfirmDialog(
                            HotelBookingGUI.this,
                            "Are you sure you want to delete the booking for " + name + "?",
                            "Confirm Deletion",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE
                        );
                        if (option == JOptionPane.YES_OPTION) {
                            deleteBooking(name);
                        }
                    }
                }
            }
        });
        
        JPanel outputPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(Color.WHITE);
                g2d.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), BORDER_RADIUS*2, BORDER_RADIUS*2));
                g2d.dispose();
            }
        };
        outputPanel.setOpaque(false);
        outputPanel.add(outputArea, BorderLayout.CENTER);
        
        JScrollPane scrollPane = new JScrollPane(outputPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        
        JPanel outputContainer = new JPanel(new BorderLayout());
        outputContainer.setOpaque(false);
        outputContainer.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createEmptyBorder(), 
            "Booking Details", 
            javax.swing.border.TitledBorder.LEFT, 
            javax.swing.border.TitledBorder.TOP,
            LABEL_FONT,
            ACCENT_COLOR));
        outputContainer.add(scrollPane, BorderLayout.CENTER);
            
        contentPanel.add(outputContainer, BorderLayout.CENTER);
        
        // Add components to booking panel
        bookingPanel.add(titlePanel, BorderLayout.NORTH);
        bookingPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Event Handlers
        addBtn.addActionListener(e -> createBooking());
        viewBtn.addActionListener(e -> readBookings());
        availabilityBtn.addActionListener(e -> checkAvailability());
    }
    
    private JTextField createStyledTextField() {
        JTextField field = new JTextField();
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        field.setFont(LABEL_FONT);
        return field;
    }
    
    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2d.setColor(darken(bgColor));
                } else if (getModel().isRollover()) {
                    g2d.setColor(brighten(bgColor));
                } else {
                    g2d.setColor(bgColor);
                }
                g2d.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), BORDER_RADIUS, BORDER_RADIUS));
                g2d.dispose();
                
                super.paintComponent(g);
            }
        };
        button.setForeground(Color.WHITE);
        button.setFont(BUTTON_FONT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        return button;
    }
    
    // Helper method to create a brighter color for hover effect
    private Color brighten(Color color) {
        int r = Math.min(255, (int)(color.getRed() * 1.2));
        int g = Math.min(255, (int)(color.getGreen() * 1.2));
        int b = Math.min(255, (int)(color.getBlue() * 1.2));
        return new Color(r, g, b);
    }
    
    // Helper method to create a darker color for pressed effect
    private Color darken(Color color) {
        int r = Math.max(0, (int)(color.getRed() * 0.8));
        int g = Math.max(0, (int)(color.getGreen() * 0.8));
        int b = Math.max(0, (int)(color.getBlue() * 0.8));
        return new Color(r, g, b);
    }

    private void createBooking() {
        String name = nameField.getText().trim();
        String room = (String) roomTypeBox.getSelectedItem();
        int nights;

        if (name.isEmpty()) {
            showErrorMessage("Name cannot be empty.");
            return;
        }

        try {
            nights = Integer.parseInt(nightsField.getText().trim());
            if (nights <= 0) {
                showErrorMessage("Number of nights must be greater than zero.");
                return;
            }
        } catch (NumberFormatException e) {
            showErrorMessage("Invalid number of nights. Please enter a valid number.");
            return;
        }
        
        // Check if rooms of the selected type are available
        try {
            int availableRooms = manager.getAvailableRooms(room.toLowerCase());
            if (availableRooms <= 0) {
                showErrorMessage("Sorry, all " + room + " rooms are fully booked. Please choose another room type or check back tomorrow.");
                return;
            }
        } catch (IOException e) {
            showErrorMessage("Error checking room availability: " + e.getMessage());
            return;
        }

        Booking booking = new Booking(name, room, nights);
        try {
            manager.addBooking(booking);
            showSuccessMessage("Booking added successfully!", 
                String.format("<b>Guest:</b> %s<br><b>Room Type:</b> %s<br><b>Nights:</b> %d<br><b>Total Cost:</b> ₱%,d", 
                booking.getName(), booking.getRoomType(), booking.getNights(), booking.getTotalCost()));
            clearFields();
        } catch (IOException e) {
            showErrorMessage("Error saving booking: " + e.getMessage());
        }
    }

    private void readBookings() {
        try {
            List<Booking> bookings = manager.getAllBookings();
            if (bookings.isEmpty()) {
                outputArea.setText("<html><body style='font-family:Segoe UI;'>No bookings found in the system.</body></html>");
                return;
            }

            // Count bookings by room type
            int singleBooked = 0;
            int doubleBooked = 0;
            int suiteBooked = 0;
            
            for (Booking b : bookings) {
                String roomType = b.getRoomType().toLowerCase();
                if (roomType.equals("single")) {
                    singleBooked++;
                } else if (roomType.equals("double")) {
                    doubleBooked++;
                } else if (roomType.equals("suite")) {
                    suiteBooked++;
                }
            }
            
            // Calculate total bookings and revenue
            int totalBookings = bookings.size();
            int totalRevenue = 0;
            for (Booking b : bookings) {
                totalRevenue += b.getTotalCost();
            }

            StringBuilder sb = new StringBuilder();
            sb.append("<html><body style='font-family:Segoe UI; font-size:13px;'>");
            
            // Add booking statistics
            sb.append("<div style='background-color:#f8f9fa; padding:15px; border-radius:5px; margin-bottom:15px;'>");
            sb.append("<h2 style='color:#2c3e50; margin-top:0;'>Booking Statistics</h2>");
            sb.append(String.format("<p><b>Total Bookings:</b> %d</p>", totalBookings));
            sb.append(String.format("<p><b>Total Revenue:</b> ₱%,d</p>", totalRevenue));
            sb.append("</div>");
            
            // Room occupancy information
            sb.append("<div style='background-color:#f8f9fa; padding:15px; border-radius:5px; margin-bottom:15px;'>");
            sb.append("<h2 style='color:#2c3e50; margin-top:0;'>Room Occupancy</h2>");
            
            // Single rooms
            int singlePercentage = (singleBooked * 100) / manager.TOTAL_SINGLE_ROOMS;
            sb.append("<div style='margin-bottom:10px;'>");
            sb.append(String.format("<p><b>Single Rooms:</b> %d/%d booked (%d%%)</p>", 
                singleBooked, manager.TOTAL_SINGLE_ROOMS, singlePercentage));
            sb.append("<div style='background-color:#ecf0f1; border-radius:4px; height:20px; width:100%;'>");
            sb.append(String.format("<div style='background-color:#3498db; border-radius:4px; height:20px; width:%d%%;'></div>", 
                singlePercentage));
            sb.append("</div></div>");
            
            // Double rooms
            int doublePercentage = (doubleBooked * 100) / manager.TOTAL_DOUBLE_ROOMS;
            sb.append("<div style='margin-bottom:10px;'>");
            sb.append(String.format("<p><b>Double Rooms:</b> %d/%d booked (%d%%)</p>", 
                doubleBooked, manager.TOTAL_DOUBLE_ROOMS, doublePercentage));
            sb.append("<div style='background-color:#ecf0f1; border-radius:4px; height:20px; width:100%;'>");
            sb.append(String.format("<div style='background-color:#2ecc71; border-radius:4px; height:20px; width:%d%%;'></div>", 
                doublePercentage));
            sb.append("</div></div>");
            
            // Suite rooms
            int suitePercentage = (suiteBooked * 100) / manager.TOTAL_SUITE_ROOMS;
            sb.append("<div style='margin-bottom:10px;'>");
            sb.append(String.format("<p><b>Suite Rooms:</b> %d/%d booked (%d%%)</p>", 
                suiteBooked, manager.TOTAL_SUITE_ROOMS, suitePercentage));
            sb.append("<div style='background-color:#ecf0f1; border-radius:4px; height:20px; width:100%;'>");
            sb.append(String.format("<div style='background-color:#9b59b6; border-radius:4px; height:20px; width:%d%%;'></div>", 
                suitePercentage));
            sb.append("</div></div>");
            
            sb.append("</div>");
            
            // Booking details
            sb.append("<div style='background-color:#f8f9fa; padding:15px; border-radius:5px;'>");
            sb.append("<h2 style='color:#2c3e50; margin-top:0;'>All Bookings</h2>");
            sb.append("<table style='width:100%; border-collapse:collapse;'>");
            sb.append("<tr style='background-color:#3498db; color:white;'>");
            sb.append("<th style='padding:10px; text-align:left; border-radius:5px 0 0 0;'>Action</th>");
            sb.append("<th style='padding:10px; text-align:left;'>Name</th>");
            sb.append("<th style='padding:10px; text-align:left;'>Room Type</th>");
            sb.append("<th style='padding:10px; text-align:left;'>Nights</th>");
            sb.append("<th style='padding:10px; text-align:left; border-radius:0 5px 0 0;'>Total Cost</th>");
            sb.append("</tr>");
            
            boolean alternate = false;
            for (Booking b : bookings) {
                String rowStyle = alternate ? "background-color:#ecf0f1;" : "background-color:#f8f9fa;";
                sb.append("<tr style='" + rowStyle + "'>");
                sb.append(String.format("<td style='padding:10px; border-top:1px solid #ddd;'><a href='delete://%s' style='background-color:#e74c3c; color:white; text-decoration:none; border-radius:4px; padding:5px 10px; display:inline-block;'>Delete</a></td>", b.getName()));
                sb.append(String.format("<td style='padding:10px; border-top:1px solid #ddd;'>%s</td>", b.getName()));
                sb.append(String.format("<td style='padding:10px; border-top:1px solid #ddd;'>%s</td>", b.getRoomType()));
                sb.append(String.format("<td style='padding:10px; border-top:1px solid #ddd;'>%d</td>", b.getNights()));
                sb.append(String.format("<td style='padding:10px; border-top:1px solid #ddd;'>₱%,d</td>", b.getTotalCost()));
                sb.append("</tr>");
                alternate = !alternate;
            }
            
            sb.append("</table>");
            sb.append("</div>");
            
            sb.append("</body></html>");
            outputArea.setText(sb.toString());
            outputArea.setCaretPosition(0);
        } catch (IOException e) {
            showErrorMessage("Error reading bookings: " + e.getMessage());
        }
    }
    
    private void showErrorMessage(String message) {
        outputArea.setText("<html><body style='font-family:Segoe UI;'>" +
            "<div style='background-color:#FFEBEE; color:#D32F2F; padding:15px; border-radius:5px;'>" +
            "<h3 style='margin-top:0;'>Error</h3>" +
            "<p>" + message + "</p>" +
            "</div></body></html>");
    }
    
    private void showSuccessMessage(String title, String details) {
        outputArea.setText("<html><body style='font-family:Segoe UI;'>" +
            "<div style='background-color:#E8F5E9; color:#2E7D32; padding:15px; border-radius:5px;'>" +
            "<h3 style='margin-top:0;'>" + title + "</h3>" +
            "<p>" + details + "</p>" +
            "</div></body></html>");
    }

    private void clearFields() {
        nameField.setText("");
        nightsField.setText("");
        roomTypeBox.setSelectedIndex(0);
    }

    // Method to handle booking deletion
    private void deleteBooking(String name) {
        try {
            manager.deleteBooking(name);
            showSuccessMessage("Booking Deleted", "The booking for " + name + " has been successfully deleted.");
            // Refresh the booking list
            readBookings();
        } catch (IOException e) {
            showErrorMessage("Error deleting booking: " + e.getMessage());
        }
    }

    private void checkAvailability() {
        try {
            StringBuilder content = new StringBuilder();
            content.append("<html><body style='font-family:Segoe UI; font-size:13px; background-color:#f8f9fa;'>");
            
            // Main container with hotel-themed styling
            content.append("<div style='padding:20px; border-radius:10px;'>");
            
            // Elegant header with hotel icon
            content.append("<div style='text-align:center; margin-bottom:25px;'>");
            content.append("<h2 style='color:#2c3e50; font-size:24px; margin:0;'>Room Availability</h2>");
            content.append("<div style='font-size:13px; color:#7f8c8d; margin-top:5px;'>Check our available accommodations</div>");
            content.append("</div>");
            
            // Get availability data
            int singleAvailable = manager.getAvailableRooms("single");
            int doubleAvailable = manager.getAvailableRooms("double");
            int suiteAvailable = manager.getAvailableRooms("suite");
            
            // Get booked rooms with guest names
            Map<String, List<String>> bookedRooms = getBookedRoomsWithGuests();
            List<String> singleBookedGuests = bookedRooms.get("single");
            List<String> doubleBookedGuests = bookedRooms.get("double");
            List<String> suiteBookedGuests = bookedRooms.get("suite");
            
            // Floor plan style container
            content.append("<div style='display:flex; flex-direction:column; gap:30px;'>");
            
            // Single rooms - Floor 1
            content.append("<div style='background-color:white; padding:20px; border-radius:10px; box-shadow:0 3px 10px rgba(0,0,0,0.08);'>");
            
            // Floor header with availability info
            int singlePercentage = (singleAvailable * 100) / manager.TOTAL_SINGLE_ROOMS;
            content.append("<div style='display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;'>");
            content.append("<div>");
            content.append("<h3 style='color:#3498db; margin:0; display:flex; align-items:center;'>");
            content.append("<span style='background-color:#3498db; color:white; width:24px; height:24px; border-radius:50%; display:flex; justify-content:center; align-items:center; margin-right:8px; font-size:12px;'>1F</span>");
            content.append("Single Rooms</h3>");
            content.append("<div style='color:#7f8c8d; margin-top:5px; font-size:12px;'>Economy class, perfect for solo travelers</div>");
            content.append("</div>");
            
            // Availability indicator
            content.append("<div style='background-color:#f8f9fa; padding:8px 15px; border-radius:20px; display:flex; align-items:center;'>");
            content.append("<div style='height:10px; width:10px; border-radius:50%; margin-right:8px; background-color:" + 
                (singleAvailable > 0 ? "#2ecc71" : "#e74c3c") + ";'></div>");
            content.append(String.format("<span><b>%d</b> of <b>%d</b> available</span>", singleAvailable, manager.TOTAL_SINGLE_ROOMS));
            content.append("</div>");
            content.append("</div>");
            
            // Room corridor visualization
            content.append("<div style='position:relative; background-color:#f5f7fa; border-radius:8px; padding:15px; margin-bottom:10px;'>");
            content.append("<div style='position:absolute; top:0; left:20px; right:20px; height:3px; background-color:#e0e6ed;'></div>"); // Corridor ceiling
            content.append("<div style='position:absolute; bottom:0; left:20px; right:20px; height:3px; background-color:#e0e6ed;'></div>"); // Corridor floor
            
            // Room doors in a row
            content.append("<div style='display:flex; justify-content:space-between; padding:0 10px;'>");
            for (int i = 0; i < manager.TOTAL_SINGLE_ROOMS; i++) {
                boolean isAvailable = i < singleAvailable;
                String guestName = "";
                if (!isAvailable && i - singleAvailable < singleBookedGuests.size()) {
                    guestName = singleBookedGuests.get(i - singleAvailable);
                    // Truncate long names
                    if (guestName.length() > 10) {
                        guestName = guestName.substring(0, 8) + "...";
                    }
                }
                
                // Door styling
                content.append("<div style='text-align:center;'>");
                content.append("<div style='width:45px; height:65px; background-color:" + 
                    (isAvailable ? "#3498db" : "#bdc3c7") + 
                    "; border-radius:5px; display:flex; flex-direction:column; justify-content:center; align-items:center; position:relative; margin-bottom:5px;'>");
                
                // Door handle
                content.append("<div style='position:absolute; right:8px; top:50%; width:6px; height:6px; background-color:#f5f7fa; border-radius:50%; transform:translateY(-50%);'></div>");
                
                // Room number
                content.append("<div style='color:white; font-weight:bold;'>" + (i+1) + "</div>");
                
                // Status indicator with guest name if occupied
                if (isAvailable) {
                    content.append("<div style='font-size:9px; color:white;'>VACANT</div>");
                } else {
                    content.append("<div style='font-size:9px; color:white;'>OCCUPIED</div>");
                    if (!guestName.isEmpty()) {
                        content.append("<div style='font-size:8px; color:white; max-width:40px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;'>" + guestName + "</div>");
                    }
                }
                content.append("</div>");
                
                // Floor number
                content.append("<div style='font-size:10px; color:#7f8c8d;'>Room " + (i+1) + "</div>");
                content.append("</div>");
            }
            content.append("</div></div>"); // End of corridor
            
            // Pricing and details
            content.append("<div style='display:flex; justify-content:space-between; font-size:12px; color:#7f8c8d;'>");
            content.append("<div>Price: ₱1,000 per night</div>");
            content.append("<div>Amenities: WiFi, TV, AC</div>");
            content.append("</div>");
            
            content.append("</div>"); // End of single rooms section
            
            // Double rooms - Floor 2
            content.append("<div style='background-color:white; padding:20px; border-radius:10px; box-shadow:0 3px 10px rgba(0,0,0,0.08);'>");
            
            // Floor header with availability info
            int doublePercentage = (doubleAvailable * 100) / manager.TOTAL_DOUBLE_ROOMS;
            content.append("<div style='display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;'>");
            content.append("<div>");
            content.append("<h3 style='color:#2ecc71; margin:0; display:flex; align-items:center;'>");
            content.append("<span style='background-color:#2ecc71; color:white; width:24px; height:24px; border-radius:50%; display:flex; justify-content:center; align-items:center; margin-right:8px; font-size:12px;'>2F</span>");
            content.append("Double Rooms</h3>");
            content.append("<div style='color:#7f8c8d; margin-top:5px; font-size:12px;'>Comfort class, ideal for couples or friends</div>");
            content.append("</div>");
            
            // Availability indicator
            content.append("<div style='background-color:#f8f9fa; padding:8px 15px; border-radius:20px; display:flex; align-items:center;'>");
            content.append("<div style='height:10px; width:10px; border-radius:50%; margin-right:8px; background-color:" + 
                (doubleAvailable > 0 ? "#2ecc71" : "#e74c3c") + ";'></div>");
            content.append(String.format("<span><b>%d</b> of <b>%d</b> available</span>", doubleAvailable, manager.TOTAL_DOUBLE_ROOMS));
            content.append("</div>");
            content.append("</div>");
            
            // Room corridor visualization
            content.append("<div style='position:relative; background-color:#f5f7fa; border-radius:8px; padding:15px; margin-bottom:10px;'>");
            content.append("<div style='position:absolute; top:0; left:20px; right:20px; height:3px; background-color:#e0e6ed;'></div>"); // Corridor ceiling
            content.append("<div style='position:absolute; bottom:0; left:20px; right:20px; height:3px; background-color:#e0e6ed;'></div>"); // Corridor floor
            
            // Room doors in a row
            content.append("<div style='display:flex; justify-content:space-between; padding:0 10px;'>");
            for (int i = 0; i < manager.TOTAL_DOUBLE_ROOMS; i++) {
                boolean isAvailable = i < doubleAvailable;
                String guestName = "";
                if (!isAvailable && i - doubleAvailable < doubleBookedGuests.size()) {
                    guestName = doubleBookedGuests.get(i - doubleAvailable);
                    // Truncate long names
                    if (guestName.length() > 10) {
                        guestName = guestName.substring(0, 8) + "...";
                    }
                }
                
                // Door styling
                content.append("<div style='text-align:center;'>");
                content.append("<div style='width:45px; height:65px; background-color:" + 
                    (isAvailable ? "#2ecc71" : "#bdc3c7") + 
                    "; border-radius:5px; display:flex; flex-direction:column; justify-content:center; align-items:center; position:relative; margin-bottom:5px;'>");
                
                // Door handle
                content.append("<div style='position:absolute; right:8px; top:50%; width:6px; height:6px; background-color:#f5f7fa; border-radius:50%; transform:translateY(-50%);'></div>");
                
                // Room number
                content.append("<div style='color:white; font-weight:bold;'>" + (i+101) + "</div>");
                
                // Status indicator with guest name if occupied
                if (isAvailable) {
                    content.append("<div style='font-size:9px; color:white;'>VACANT</div>");
                } else {
                    content.append("<div style='font-size:9px; color:white;'>OCCUPIED</div>");
                    if (!guestName.isEmpty()) {
                        content.append("<div style='font-size:8px; color:white; max-width:40px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;'>" + guestName + "</div>");
                    }
                }
                content.append("</div>");
                
                // Floor number
                content.append("<div style='font-size:10px; color:#7f8c8d;'>Room " + (i+101) + "</div>");
                content.append("</div>");
            }
            content.append("</div></div>"); // End of corridor
            
            // Pricing and details
            content.append("<div style='display:flex; justify-content:space-between; font-size:12px; color:#7f8c8d;'>");
            content.append("<div>Price: ₱1,800 per night</div>");
            content.append("<div>Amenities: WiFi, TV, AC, Mini Bar</div>");
            content.append("</div>");
            
            content.append("</div>"); // End of double rooms section
            
            // Suite rooms - Floor 3
            content.append("<div style='background-color:white; padding:20px; border-radius:10px; box-shadow:0 3px 10px rgba(0,0,0,0.08);'>");
            
            // Floor header with availability info
            int suitePercentage = (suiteAvailable * 100) / manager.TOTAL_SUITE_ROOMS;
            content.append("<div style='display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;'>");
            content.append("<div>");
            content.append("<h3 style='color:#9b59b6; margin:0; display:flex; align-items:center;'>");
            content.append("<span style='background-color:#9b59b6; color:white; width:24px; height:24px; border-radius:50%; display:flex; justify-content:center; align-items:center; margin-right:8px; font-size:12px;'>3F</span>");
            content.append("Suite Rooms</h3>");
            content.append("<div style='color:#7f8c8d; margin-top:5px; font-size:12px;'>Luxury class, spacious accommodation with premium amenities</div>");
            content.append("</div>");
            
            // Availability indicator
            content.append("<div style='background-color:#f8f9fa; padding:8px 15px; border-radius:20px; display:flex; align-items:center;'>");
            content.append("<div style='height:10px; width:10px; border-radius:50%; margin-right:8px; background-color:" + 
                (suiteAvailable > 0 ? "#2ecc71" : "#e74c3c") + ";'></div>");
            content.append(String.format("<span><b>%d</b> of <b>%d</b> available</span>", suiteAvailable, manager.TOTAL_SUITE_ROOMS));
            content.append("</div>");
            content.append("</div>");
            
            // Room corridor visualization
            content.append("<div style='position:relative; background-color:#f5f7fa; border-radius:8px; padding:15px; margin-bottom:10px;'>");
            content.append("<div style='position:absolute; top:0; left:20px; right:20px; height:3px; background-color:#e0e6ed;'></div>"); // Corridor ceiling
            content.append("<div style='position:absolute; bottom:0; left:20px; right:20px; height:3px; background-color:#e0e6ed;'></div>"); // Corridor floor
            
            // Room doors in a row
            content.append("<div style='display:flex; justify-content:space-between; padding:0 10px;'>");
            for (int i = 0; i < manager.TOTAL_SUITE_ROOMS; i++) {
                boolean isAvailable = i < suiteAvailable;
                String guestName = "";
                if (!isAvailable && i - suiteAvailable < suiteBookedGuests.size()) {
                    guestName = suiteBookedGuests.get(i - suiteAvailable);
                    // Truncate long names
                    if (guestName.length() > 10) {
                        guestName = guestName.substring(0, 8) + "...";
                    }
                }
                
                // Door styling - suites are larger
                content.append("<div style='text-align:center;'>");
                content.append("<div style='width:55px; height:75px; background-color:" + 
                    (isAvailable ? "#9b59b6" : "#bdc3c7") + 
                    "; border-radius:5px; display:flex; flex-direction:column; justify-content:center; align-items:center; position:relative; margin-bottom:5px;'>");
                
                // Door handle
                content.append("<div style='position:absolute; right:8px; top:50%; width:6px; height:6px; background-color:#f5f7fa; border-radius:50%; transform:translateY(-50%);'></div>");
                
                // Room number
                content.append("<div style='color:white; font-weight:bold;'>" + (i+201) + "</div>");
                
                // Status indicator with guest name if occupied
                if (isAvailable) {
                    content.append("<div style='font-size:9px; color:white;'>VACANT</div>");
                } else {
                    content.append("<div style='font-size:9px; color:white;'>OCCUPIED</div>");
                    if (!guestName.isEmpty()) {
                        content.append("<div style='font-size:8px; color:white; max-width:50px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;'>" + guestName + "</div>");
                    }
                }
                content.append("</div>");
                
                // Floor number
                content.append("<div style='font-size:10px; color:#7f8c8d;'>Suite " + (i+201) + "</div>");
                content.append("</div>");
            }
            content.append("</div></div>"); // End of corridor
            
            // Pricing and details
            content.append("<div style='display:flex; justify-content:space-between; font-size:12px; color:#7f8c8d;'>");
            content.append("<div>Price: ₱3,500 per night</div>");
            content.append("<div>Amenities: WiFi, TV, AC, Mini Bar, Jacuzzi, King Bed</div>");
            content.append("</div>");
            
            content.append("</div>"); // End of suite rooms section
            
            content.append("</div>"); // End of floor plan container
            
            // Legend and hotel info
            content.append("<div style='margin-top:20px; background-color:white; padding:15px; border-radius:10px; box-shadow:0 3px 10px rgba(0,0,0,0.08);'>");
            content.append("<div style='display:flex; justify-content:space-between;'>");
            
            // Legend
            content.append("<div>");
            content.append("<div style='font-weight:bold; margin-bottom:10px; color:#2c3e50;'>Room Status</div>");
            content.append("<div style='display:flex; gap:15px;'>");
            
            content.append("<div style='display:flex; align-items:center; gap:5px;'>");
            content.append("<div style='width:12px; height:12px; border-radius:50%; background-color:#2ecc71;'></div>");
            content.append("<span style='font-size:12px;'>Available</span>");
            content.append("</div>");
            
            content.append("<div style='display:flex; align-items:center; gap:5px;'>");
            content.append("<div style='width:12px; height:12px; border-radius:50%; background-color:#bdc3c7;'></div>");
            content.append("<span style='font-size:12px;'>Occupied</span>");
            content.append("</div>");
            content.append("</div>");
            content.append("</div>");
            
            // Hotel info
            content.append("<div>");
            content.append("<div style='font-weight:bold; margin-bottom:10px; color:#2c3e50;'>Hotel Information</div>");
            content.append("<div style='font-size:12px; color:#7f8c8d;'>Check-in: 2:00 PM | Check-out: 12:00 PM</div>");
            content.append("<div style='font-size:12px; color:#7f8c8d;'>Front Desk: Available 24/7</div>");
            content.append("</div>");
            
            content.append("</div>");
            content.append("</div>"); // End of legend and hotel info
            
            content.append("</div>"); // End of main container
            content.append("</body></html>");
            
            // Display the availability information in the output area
            outputArea.setText(content.toString());
            outputArea.setCaretPosition(0);
            
        } catch (IOException e) {
            showErrorMessage("Error checking availability: " + e.getMessage());
        }
    }

    // Helper method to get a map of booked rooms with guest names
    private Map<String, List<String>> getBookedRoomsWithGuests() throws IOException {
        List<Booking> bookings = manager.getAllBookings();
        Map<String, List<String>> bookedRooms = new HashMap<>();
        
        // Initialize lists for each room type
        bookedRooms.put("single", new ArrayList<>());
        bookedRooms.put("double", new ArrayList<>());
        bookedRooms.put("suite", new ArrayList<>());
        
        // Add guest names to appropriate lists
        for (Booking booking : bookings) {
            String roomType = booking.getRoomType().toLowerCase();
            if (bookedRooms.containsKey(roomType)) {
                bookedRooms.get(roomType).add(booking.getName());
            }
        }
        
        return bookedRooms;
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new HotelBookingGUI());
    }
}
